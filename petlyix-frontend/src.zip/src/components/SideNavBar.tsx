import {
 
  IconPaw,
  IconFirstAidKit,
  IconLogout,
  IconDeviceDesktopAnalytics,
  IconBowl,
  IconSettings,
  IconSwitchHorizontal,
} from '@tabler/icons-react';
import { Code, Group } from '@mantine/core';
import { Logo } from './Logo';
import classes from '../styles/SideNavBar.module.css';
import { NavLink, useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import { useAuth } from '../hooks/useState';




export function SideNavBar() {
const navigate = useNavigate();
const { logout } = useAuth();

const { petId } = useParams();
const logoutHandler = () =>{
  navigate("/");
  logout();
}
const generalLinks = [
  { link: '/pets', label: 'My Pets', icon: IconPaw },
  { link: '/settings', label: 'Settings', icon: IconSettings },
];

const petSpecificLinks = [
  { link: `/pets/${petId}`, label: 'Overview', icon: IconDeviceDesktopAnalytics },
  { link: `/pets/${petId}/feeding`, label: 'Feeding', icon: IconBowl },
  { link: `/pets/${petId}/health`, label: 'Health', icon: IconFirstAidKit },
  { link: `/pets/${petId}/manage`, label: 'Manage Pet', icon: IconSettings },
];

const linksToRender = petId ? petSpecificLinks : generalLinks;

 const links = linksToRender.map((item) => (
  <NavLink
  to={item.link}
  end
  key={item.label}
  className={({ isActive }) => classes.link + (isActive ? ` ${classes.activeLink}` : '')}
 >
    <item.icon className={classes.linkIcon} stroke={1.5} />
    <span>{item.label}</span>
  </NavLink>
));

  return (
    <nav className={classes.navbar}>
      <div className={classes.navbarMain}>
        <Group className={classes.header} justify="space-between">
          <Logo />
          <Code fw={700}>v3.1.2</Code>
        </Group>
        {links}
      </div>

      <div className={classes.footer}>
        <a href="#" className={classes.link} onClick={(event) => event.preventDefault()}>
          <IconSwitchHorizontal className={classes.linkIcon} stroke={1.5} />
          <span>Change account</span>
        </a>

        <a href="#" className={classes.link} onClick={logoutHandler}>
          <IconLogout className={classes.linkIcon} stroke={1.5} />
          <span>Logout</span>
        </a>
      </div>
    </nav>
  );
}